﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShipIt
{
    class IShippable
    {
        public decimal ShipCost { get; set; }
        public string Product { get; set; }
    }
}
