﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShipIt
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IShippable> Cart = new List<IShippable>();
            Menu();
            while (1 == 1)
            {
                Shipper(Cart);
            }
        }
        static void Menu()
        {
            Console.WriteLine("Choose from the following options:");
            Console.WriteLine();
            Console.WriteLine("1.Add a bicycle to the shipment");
            Console.WriteLine("2.Add a Lawn Mower to the shipment");
            Console.WriteLine("3.Add a Baseball Glove to the shipment");
            Console.WriteLine("4.Add Crackers to the shipment");
            Console.WriteLine("5.List Shipment Items");
            Console.WriteLine("6.Compute Shipping Charges");
        }
        static void Add(IShippable item, List<IShippable> Cart)
        {
            Cart.Add(item);
        }
        static void Shipper(List<IShippable> Cart)
        {
            decimal bicycle = 20.50M;
            decimal lawnMower = 24.00M;
            decimal baseballGlove = 3.23M;
            decimal crackers = 0.57M;
            IShippable item = new IShippable();

            int choice = int.Parse(Console.ReadLine());
            
            if (choice == 1)
            {
                item.ShipCost = bicycle;
                item.Product = "Bicycle";
                Add(item, Cart);
                Console.WriteLine("1 Bicycle has been added");
            }
            if (choice == 2)
            {
                item.ShipCost = lawnMower;
                item.Product = "Lawn Mower";
                Add(item, Cart);
                Console.WriteLine("1 Lawn Mower has been added");
            }
            if (choice == 3)
            {
                item.ShipCost = baseballGlove;
                item.Product = "Baseball Glove";
                Add(item, Cart);
                Console.WriteLine("1 Baseball Glove has been added");
            }
            if (choice == 4)
            {
                item.ShipCost = crackers;
                item.Product = "Crackers";
                Add(item, Cart);
                Console.WriteLine("Crackers have been added");
            }
            if (choice == 5)
            {
                ListCart(Cart);
            }
            if(choice == 6)
            {
                ComputeShipping(Cart);
                //Console.WriteLine("Press any key to terminate the program.");


            }
        }
        static void ListCart(List<IShippable> Cart)
        {
            int bicycleCount = 0;
            int lawnMowerCount = 0;
            int baseballGloveCount = 0;
            int crackersCount = 0;

            foreach (var item in Cart)
            {
                if (item.Product == "Bicycle")
                {
                    bicycleCount++;
                }
                if (item.Product == "Lawn Mower")
                {
                    lawnMowerCount++;
                }
                if (item.Product == "Baseball Glove")
                {
                    baseballGloveCount++;
                }
                if (item.Product == "Crackers")
                {
                    crackersCount++;
                }
            }
            Console.WriteLine("Shipment Manifest");
            if (bicycleCount == 1)
            {
                Console.WriteLine("1 Bicycle");
            }
            if (bicycleCount > 1)
            {
                Console.WriteLine(bicycleCount + " Bicycles");
            }
            if (lawnMowerCount == 1)
            {
                Console.WriteLine("1 Lawn Mower");
            }
            if (lawnMowerCount > 1)
            {
                Console.WriteLine(lawnMowerCount + " Lawn Mowers");
            }
            if (baseballGloveCount == 1)
            {
                Console.WriteLine("1 Baseball Glove");
            }
            if (baseballGloveCount > 1)
            {
                Console.WriteLine(baseballGloveCount + " Baseball Gloves");
            }
            if (crackersCount == 1)
            {
                Console.WriteLine("1 Crackers");
            }
            if (crackersCount > 1)
            {
                Console.WriteLine(crackersCount + " Crackers");
            }
        }
        static void ComputeShipping(List<IShippable> Cart)
        {
            decimal totalCost = 0.00M;
            foreach (var item in Cart)
            {
                if (item.Product == "Bicycle")
                {
                    totalCost = totalCost + 20.50m;
                }
                if (item.Product == "Lawn Mower")
                {
                    totalCost = totalCost + 24.00m;
                }
                if (item.Product == "Baseball Glove")
                {
                    totalCost = totalCost + 3.23m;
                }
                if (item.Product == "Crackers")
                {
                    totalCost = totalCost + 0.57m;
                }
            }
            Console.WriteLine("Total shipping costs for this order are $" + totalCost);
        }
    }
}
